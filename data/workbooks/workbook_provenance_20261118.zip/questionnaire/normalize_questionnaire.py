"""Turn extracted official overview question cells into a complete indexed catalogue."""
from pathlib import Path
import re,json
OUT=Path(__file__).resolve().parent
raw=json.loads((OUT/'raw_question_cells.json').read_text(encoding='utf8'))

def readable(s):
    # Remove only typesetting breaks inside a word; retain raw source text separately.
    s=re.sub(r'(?<=\w)-\n(?=[a-zäöüß])','',s)
    s=re.sub(r'(?<=/)\n','',s)
    return re.sub(r'\s+',' ',s).strip()

sections=[
    (6,7,'Haushaltsfragebogen','',6),
    (8,8,'Detailerfassung Pkw (im Haushaltsfragebogen)','Berücksichtigung von bis zu drei Pkw des Haushalts; Beginn mit meistgenutztem Pkw',8),
    (9,19,'Personenfragebogen','Aufnahme von bis zu acht Personen im Haushalt; Personen unter 14 Jahren mit verkürztem Kinderfragebogen; Stellvertreterfragebogen für Personen ab 14 Jahre ebenfalls gekürzt',9),
    (20,21,'Zusatzmodul Reisen mit Übernachtung (im Personenfragebogen)','Detailerfassung für bis zu drei Reisen mit Übernachtung in den letzten drei Monaten; Beginn mit letzter Reise',20),
    (22,23,'Zusatzmodul Tagesreisen (im Personenfragebogen)','Detailerfassung für bis zu drei Tagesreisen in den letzten vier Wochen; Beginn mit letzter Tagesreise',22),
    (24,26,'Allgemeine Angaben zum Stichtag (im Personenfragebogen)','',24),
    (27,27,'Regelmäßige berufliche Wege am Stichtag (rbW) (im Personenfragebogen)','nur bei erwerbstätigen Personen ab 16 Jahre, ohne Stellvertreterinterviews',27),
    (28,31,'Wegeerfassung (im Personenfragebogen)','Detailaufnahme von bis zu acht Wegen beim PAPI und zwölf Wegen beim CATI/CAWI; Im CATI- und CAWI-Interview wurde vor der detaillierten Erfassung der einzelnen Wege zunächst eine Tagesübersicht aller Wege mit den Merkmalen Startzeit, Ankunftszeit, Wegezweck und Verkehrsmittel erstellt.',28),
    (32,32,'Etappenerfassung (im Personenfragebogen)','Die ausgewählten Personen wurden zu ihren Etappen befragt, wenn sie zuvor Wege mit mehreren Verkehrsmitteln berichtet haben.',32)
]
bases={
 'CAR':('Auswahl von 50 Prozent der Stichprobe; Beantwortung nur von CAWI- und CATI-Teilnehmern; beim PAPI wurden die Fragen nicht gestellt.',6),
 'PERS':('je Modul Auswahl von 50 Prozent der Stichprobe (außer Modul Zufriedenheit: 25 Prozent der Stichprobe); Beantwortung nur von CAWI- und CATI-Teilnehmern; beim PAPI wurden die Fragen meist nicht gestellt.',9),
 'REISE':('25 Prozent der Stichprobe; Beantwortung nur von CAWI- und CATI-Teilnehmern (ab 14 Jahre, ohne Stellvertreterinterviews); beim PAPI wurden die Fragen nicht gestellt.',20),
 'TR':('25 Prozent der Stichprobe; Beantwortung nur von CAWI- und CATI-Teilnehmern (ab 14 Jahre, ohne Stellvertreterinterviews); beim PAPI wurden die Fragen nicht gestellt.',22),
 'ETAP':('Auswahl von 50 Prozent der Stichprobe; Beantwortung nur von CAWI- und CATI-Teilnehmern; beim PAPI wurden die Fragen nicht gestellt.',32)
}
for m in ['RAD','NET','ZUF','MOB','OPNV','HOFF']:bases[m]=bases['PERS']

merged=[]
for c in raw:
    if c['pdf_page']==5:continue
    c=dict(c);c['fragments']=[dict(c)]
    if not c['field_raw'].strip():
        assert merged and c['pdf_page']==10 and c['question_answer_raw'].startswith('B:'),c
        merged[-1]['question_answer_raw']+='\n'+c['question_answer_raw']
        merged[-1]['fragments'].append(c['fragments'][0])
    else:merged.append(c)

questions=[];options=[];issues=[]
option_re=re.compile(r'^([A-Z]|\d{1,3}):\s*(.*)$')
split_re=re.compile(r'^(?:[A-Z]|\d{1,3}):|^(?:offene Angabe|offen in|Angabe Uhrzeit|Aufnahme Ort|Mehrfachnennungen)',re.I)

for qi,c in enumerate(merged,1):
    pp=c['pdf_page'];qid=f'MID2023_Q{qi:03}'
    sec=next(s for s in sections if s[0]<=pp<=s[1])
    lines=c['question_answer_raw'].splitlines()
    start=next((i for i,line in enumerate(lines)if split_re.search(line.strip())),len(lines))
    qraw='\n'.join(lines[:start]);araw='\n'.join(lines[start:])
    # Capture source names exactly, including source spelling and variable families.
    field_join=re.sub(r'\n(?=_[A-Z])','',c['field_raw'])
    variable_names=re.findall(r'\(([A-Za-zÄÖÜäöü][A-Za-zÄÖÜäöü0-9_\-\s]*_[A-Za-zÄÖÜäöü0-9_\-\s]+)\)',field_join)
    variable_names=[re.sub(r'\s+','',v)for v in variable_names]
    if not variable_names:
        variable_names=re.findall(r'\bP_NEBEN_ENTF\b|\bwegkm\b',field_join)
    if not variable_names and 'Ausgangspunkt'not in c['field_raw'] and c['field_raw']!='Zielort':issues.append({'question_id':qid,'issue':'No variable label parsed','raw':c['field_raw']})
    module=readable(c['module_raw'])
    module_name=re.search(r'Modul\s+(\w+)',module)
    basis=bases.get(module_name.group(1))if module_name else None
    prefix=[]
    for line in qraw.splitlines():
        if line.startswith(('Bei Wegen','nach dem','Abfrage pro Etappe','Unabhängig von Ihrem Berichtstag')):
            prefix.append(line)
    # Wrapped prefix can extend to next line up to the colon.
    if qraw.startswith(('Bei Wegen','nach dem','Abfrage pro Etappe','Unabhängig von Ihrem Berichtstag')) and ':'in qraw:
        prefix=[readable(qraw.split(':',1)[0])+':']
    eligibility_parts=[x for x in [sec[3],basis[0]if basis else '',module if 'nur'in module or 'alle'in module else '',*prefix]if x]
    reference=''
    if 20<=pp<=21:reference='in den letzten drei Monaten'
    elif 22<=pp<=23:reference='in den letzten vier Wochen'
    elif 24<=pp<=32:reference='Stichtag / Berichtstag'
    else:
        for pattern in [r'in der Regel',r'pro Jahr',r'zurzeit',r'üblicherweise',r'normalerweise',r'pro Woche',r'unabhängig vom Stichtag']:
            m=re.search(pattern,readable(qraw),re.I)
            if m:reference=m.group();break
    record={
      'question_id':qid,'section':sec[2],'field_label':readable(re.sub(r'\([^)]*_[^)]*\)','',field_join)),
      'variable_raw':'; '.join(variable_names),'variables':variable_names,
      'question_text':readable(qraw),'answer_options':readable(araw),
      'answer_options_multiline':araw,'module':module,
      'universe_filter':' | '.join(eligibility_parts)or 'Nicht in dieser Fragenübersicht näher angegeben',
      'universe_source_pages':sorted(set([sec[4]]+([basis[1]]if basis else[])+[pp])),
      'reference_period':reference or 'Nicht ausdrücklich angegeben',
      'reference_period_note':'Inherited from section heading/context'if 20<=pp<=32 else'Literal wording where available; no recall period inferred',
      'pdf_pages':sorted(set(f['pdf_page']for f in c['fragments'])),
      'overview_pages':sorted(set(f['overview_page']for f in c['fragments'])),
      'response_type':'Mehrfachnennungen'if'Mehrfachnennungen'in araw else('offene Angabe'if re.search(r'offen|Angabe Uhrzeit|Aufnahme Ort',araw,re.I)else'kodierte Antwortkategorien'),
      'scope_note':'Originalwortlaut der Fragenübersicht (CATI/CAWI). Vollständige Filter und Erhebungsmethodenunterschiede stehen im Fragebogenmaster. Fragebogencodes können von Datensatzcodes abweichen.',
      'raw_field':c['field_raw'],'raw_question_text':qraw,'raw_question_and_answers':c['question_answer_raw'],'raw_module':c['module_raw'],
      'source_file':'infas_ErgänzendeStudienunterlagen_MiD2023_7555.pdf',
      'source_url':'https://www.mobilitaet-in-deutschland.de/pdf/infas_Erg%C3%A4nzendeStudienunterlagen_MiD2023_7555.pdf'
    }
    questions.append(record)
    # A second long table supplies exact displayed codes without inventing omitted scale labels.
    current=None;qualifier='';local=[]
    def finish():
        global current
        if current is not None:local.append(current);current=None
    for line in araw.splitlines():
        line=line.strip();m=option_re.match(line)
        if m:
            finish();code=m.group(1)
            current={'code':code,'label_raw':m.group(2),'qualifier':qualifier,'option_kind':'Itemkennung'if code.isalpha()else'Antwortcode'}
        elif line in ('…','...'):
            finish();local.append({'code':'','label_raw':line,'qualifier':qualifier,'option_kind':'Auslassungszeichen im Original'})
        elif line.startswith('nur ')and line.endswith(':'):
            finish();qualifier=line
        elif current is not None:current['label_raw']+='\n'+line
        elif line and line!='Mehrfachnennungen':
            local.append({'code':'','label_raw':line,'qualifier':qualifier,'option_kind':'Antwortformat oder Hinweis'})
    finish()
    if not local:issues.append({'question_id':qid,'issue':'No answer options/format parsed'})
    for oi,o in enumerate(local,1):
        options.append({'question_id':qid,'option_order':oi,'variable_raw':record['variable_raw'],'section':record['section'],
                        **o,'answer_label':readable(o['label_raw']),'pdf_pages':record['pdf_pages'],'overview_pages':record['overview_pages']})

assert len(questions)==125,len(questions)
assert len({q['question_id']for q in questions})==len(questions)
assert all(q['question_text']and q['answer_options']for q in questions)
for name,data in [('questions.json',questions),('answer_options.json',options),('extraction_issues.json',issues),('section_context.json',{'sections':sections,'module_bases':bases})]:
    (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
summary={'question_blocks':len(questions),'answer_rows':len(options),'raw_cells':len(raw),'diagram_cells_excluded':1,'cross_page_merges':[{'variable':'P_CS_A-D','pdf_pages':[9,10]}],'sections':{s[2]:sum(q['section']==s[2]for q in questions)for s in sections},'issues':issues,'preserved_source_spelling':['P_KENN_ÖPNV','Stichtagt in field label'],'missing_variable_labels':['Startort 1. Weg – Ausgangspunkt','Zielort'],'scale_ellipsis':'Intermediate labels omitted in source are not invented'}
(OUT/'extraction_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False))

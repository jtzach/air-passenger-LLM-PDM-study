"""Read-only completeness checks for the overview questionnaire extraction."""
from pathlib import Path
import json,re
OUT=Path(__file__).resolve().parent
questions=json.loads((OUT/'questions.json').read_text(encoding='utf8'))
options=json.loads((OUT/'answer_options.json').read_text(encoding='utf8'))
by_id={q['question_id']:q for q in questions}
for q in questions:
    source_codes=re.findall(r'^([A-Z]|\d{1,3}):',q['answer_options_multiline'],re.M)
    output_codes=[o['code']for o in options if o['question_id']==q['question_id']and o['code']]
    assert source_codes==output_codes,(q['question_id'],source_codes,output_codes)
    assert q['pdf_pages']==[p+3 for p in q['overview_pages']]
    assert q['question_text']and q['answer_options']
assert all(o['question_id']in by_id for o in options)
report={
 'question_blocks':len(questions),'answer_rows':len(options),
 'all_source_answer_codes_preserved_in_order':True,
 'all_overview_page_locators_match_pdf_offset':True,
 'unreadable_question_tables':[],
 'source_omissions_preserved':['Two address/location questions have no variable label in overview','Some attitude scales show only endpoint labels with an ellipsis','The overview does not provide the full routing/master specification'],
 'visual_checks_pdf_pages':[6,9,13,21,32],
 'normalisation':'Only line-wrap whitespace and intra-word typesetting hyphens joined; raw source cells and all pages retained',
 'questionnaire_scope':'All question blocks in overview physical pages6–32; note/diagram on page5 archived separately; not all questions/variants in full CATI/CAWI/PAPI masters'
}
(OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False))

"""Extract all question/answer cells in the official MiD2023 overview, PDF pp5–32.

The original line breaks are preserved in raw_* fields. Readable text joins source
lines; no question or option is paraphrased. Dataset coding is a separate source.
"""
from pathlib import Path
import json, hashlib, re
import pdfplumber

OUT=Path(__file__).resolve().parent
SOURCE=OUT.parents[1]/'mid2023_aircraft_20261118/sources/infas_ErgänzendeStudienunterlagen_MiD2023_7555.pdf'
OUT.mkdir(parents=True,exist_ok=True)

def write(name,obj):
    (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8')

pages=[]; cells=[]
with pdfplumber.open(SOURCE) as doc:
    for i in range(4,32):
        page=doc.pages[i]
        txt=page.extract_text(x_tolerance=1.5,y_tolerance=3)
        (OUT/f'raw_page_{i+1:03}.txt').write_text(txt or '',encoding='utf8')
        tables=page.find_tables()
        rawtables=[]
        for tn,t in enumerate(tables,1):
            matrix=t.extract(x_tolerance=1.5,y_tolerance=3)
            rawtables.append({'table_number':tn,'bbox':t.bbox,'matrix':matrix})
            if t.bbox[0]<160: continue  # Overview module legend, not question table.
            for rn,row in enumerate(t.rows,1):
                box=row.cells[0]
                if box is None or box[2]-box[0]<170: continue
                text=matrix[rn-1][0]
                if not text or text.strip()=='Frage und Antwortmöglichkeiten':continue
                left=page.crop((box[0]-70,box[1],box[0]-.15,box[3])).extract_text(x_tolerance=1.5,y_tolerance=3) or ''
                right=page.crop((box[2]+.1,box[1],t.bbox[2]+2,box[3])).extract_text(x_tolerance=1.5,y_tolerance=3) or ''
                cells.append({'pdf_page':i+1,'overview_page':i-2,'table_number':tn,'row_number':rn,'bbox':list(box),'field_raw':left,'question_answer_raw':text,'module_raw':right})
        pages.append({'pdf_page':i+1,'overview_page':i-2,'text':txt,'tables':rawtables})
write('raw_pages.json',pages)
write('raw_question_cells.json',cells)
write('source_manifest.json',{'source_file':str(SOURCE.resolve()),'source_url':'https://www.mobilitaet-in-deutschland.de/pdf/infas_Erg%C3%A4nzendeStudienunterlagen_MiD2023_7555.pdf','sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'pdf_pages_in_scope':list(range(5,33)),'scope_note':'Questions overview only. Page5 states that detailed filters and survey-mode variants must be checked against full questionnaires/master. Question codes can differ from released dataset codes.'})
print(json.dumps({'pages':len(pages),'question_cells':len(cells)},ensure_ascii=False))

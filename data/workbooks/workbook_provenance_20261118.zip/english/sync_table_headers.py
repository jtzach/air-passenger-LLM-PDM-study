"""Synchronise table-column metadata with artifact-tool-authored header cells.

The documented artifact-tool surface does not expose a table-column rename setter.
Only xl/tables/*.xml metadata is repaired; worksheet cells and all other ZIP parts
remain byte-identical to the artifact-tool export.
"""
from pathlib import Path
import json,re,posixpath,zipfile,xml.etree.ElementTree as E
R=Path(__file__).resolve().parent
f=R/'MiD2023_Comprehensive_Data_EN.xlsx'
ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
E.register_namespace('',ns['s'])
def target(base,value):return value.lstrip('/') if value.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(base),value))
def relations(z,part):
    p=posixpath.join(posixpath.dirname(part),'_rels',posixpath.basename(part)+'.rels')
    return {e.attrib['Id']:target(part,e.attrib['Target']) for e in E.fromstring(z.read(p))} if p in z.namelist() else {}
def letters(n):
    s=''
    while n:n,k=divmod(n-1,26);s=chr(65+k)+s
    return s
changed={};report=[]
with zipfile.ZipFile(f) as z:
    ss=[]
    if 'xl/sharedStrings.xml' in z.namelist():
        ss=[''.join(t.text or '' for t in x.iter('{'+ns['s']+'}t')) for x in E.fromstring(z.read('xl/sharedStrings.xml'))]
    wr=relations(z,'xl/workbook.xml')
    for s in E.fromstring(z.read('xl/workbook.xml')).find('s:sheets',ns):
        part=wr[s.attrib['{'+ns['r']+'}id']];root=E.fromstring(z.read(part));sr=relations(z,part)
        for tp in root.findall('s:tableParts/s:tablePart',ns):
            tablepart=sr[tp.attrib['{'+ns['r']+'}id']];table=E.fromstring(z.read(tablepart))
            start=re.match(r'([A-Z]+)(\d+)',table.attrib['ref']);startcol=0
            for x in start[1]:startcol=startcol*26+ord(x)-64
            rownum=int(start[2]);row=root.find(f's:sheetData/s:row[@r="{rownum}"]',ns)
            cells={c.attrib['r']:c for c in row};edits=[]
            for i,column in enumerate(table.find('s:tableColumns',ns)):
                c=cells[letters(startcol+i)+str(rownum)];v=c.find('s:v',ns)
                name=ss[int(v.text)] if c.attrib.get('t')=='s' else ''.join(t.text or '' for t in c.findall('.//s:t',ns)) if c.attrib.get('t')=='inlineStr' else v.text
                if column.attrib['name']!=name:edits.append({'old':column.attrib['name'],'new':name});column.set('name',name)
            if edits:changed[tablepart]=E.tostring(table,encoding='utf-8',xml_declaration=True);report.append({'sheet':s.attrib['name'],'table':table.attrib['name'],'headers':edits})
    if changed:
        temp=f.with_suffix('.tmp.xlsx')
        with zipfile.ZipFile(temp,'w') as out:
            for info in z.infolist():out.writestr(info,changed.get(info.filename,z.read(info.filename)))
if changed:temp.replace(f)
(R/'table_header_metadata_repair.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'tables_synchronised':len(report),'headers_synchronised':sum(len(r['headers']) for r in report)}))

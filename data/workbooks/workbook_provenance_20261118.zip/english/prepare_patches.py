"""Prepare explicit text-only English edits; leave all measurements and codes intact."""
from pathlib import Path
from collections import defaultdict
import json,re,hashlib
from openpyxl import load_workbook

R=Path(__file__).resolve().parent
inv=json.loads((R/'cell_inventory.json').read_text(encoding='utf8'))
cat=json.loads((R/'string_catalogue.json').read_text(encoding='utf8'))
maps={}
for group in ['questionnaire','codebook','context']:
    f=R/f'translations_{group}.json'
    part=json.loads(f.read_text(encoding='utf8'))
    expected={r['id'] for r in cat if r['group']==group}
    assert expected==set(part),(group,len(expected-set(part)),len(set(part)-expected))
    assert not set(part)&set(maps)
    maps.update(part)
assert all(isinstance(v,str) and v for v in maps.values())
patches={}
def patch(sheet,cell,source,value,reason):
    if source!=value:patches[(sheet,cell)]={'sheet':sheet,'cell':cell,'source':source,'translation':value,'reason':reason}
for c in inv['cells']:patch(c['sheet'],c['cell'],c['source'],maps[c['id']],'translation')

# City and municipality names are official identifiers. Translate only appended
# administrative descriptors, not names, geographic qualifiers or civic epithets.
qualifiers={
'Stadt':'city','St':'city','M':'market town','GKSt':'major district town',
'Flecken':'market town','Hansestadt':'Hanseatic city','gemfr. Gebiet':'unincorporated area',
'Kreisstadt':'district capital','Landeshauptstadt':'state capital','Universitätsstadt':'university city',
'Ostseebad':'Baltic seaside resort','kreisfreie Stadt':'independent city','Marktflecken':'market town',
'Marktgemeinde':'market municipality','Stadtkreis':'urban district','Seebad':'seaside resort',
'Hochschulstadt':'university town','Freie und Hansestadt':'Free and Hanseatic City',
'Stadt der FernUniversität':'city of the distance-learning university','Wissenschaftsstadt':'science city',
'Stadt, Hochschulstadt':'city, university town','gemfr. Geb.':'unincorporated area',
'gemfr. Bezirk':'unincorporated district','Nationalparkgemeinde':'national park municipality',
'Nationalparkstadt':'national park city','gemeindefreies Gebiet':'unincorporated area',
'Ostseeheilbad':'Baltic seaside health resort','Berg- und Universitätsstadt':'mining and university town',
'Burggemeinde':'castle municipality','Sport- und Freizeitgemeinde':'sports and leisure municipality',
'Dom- und Kaiserstadt':'cathedral and imperial city','Hansestadt, Kreisstadt':'Hanseatic city, district capital',
'Hanse- und Universitätsstadt':'Hanseatic and university city','Residenzstadt':'former royal-residence city',
'Universitäts- und Hansestadt':'university and Hanseatic city','Stadt, Garnisonsstadt':'city, garrison town',
'Stadt, Universitätsstadt':'city, university city','Welterbestadt':'World Heritage city',
'Ostseebad, Stadt':'Baltic seaside resort, city','Kurort':'spa resort',
'Kreis- und  Hochschulstadt':'district capital and university town',
'Kreis- und Hochschulstadt':'district capital and university town',
'Inselgemeinde':'island municipality','Nordseebad':'North Sea seaside resort',
'Kurort, Stadt':'spa resort, city','Stadt / Bela Woda':'city / Bela Woda',
'Kirchspiel':'parish','Klostergemeinde':'monastery municipality','Seegemeinde':'lakeside municipality',
'Inselstadt':'island town','Fischerdorf':'fishing village','Seebad , Stadt':'seaside resort, city',
'Seebad, Stadt':'seaside resort, city','Stadt / Běła Woda':'city / Běła Woda',
}
for c in inv['geographic_names']:
    v=c['source']
    if v=='keine Stadtregion':new='No urban region'
    elif ', ' in v:
        name,suffix=v.split(', ',1)
        new=name+', '+qualifiers.get(suffix,', '.join(qualifiers.get(x,x) for x in suffix.split(', ')))
    else:new=v
    patch(c['sheet'],c['cell'],v,new,'administrative descriptor')

wb=load_workbook(inv['source_file'],read_only=False,data_only=False)
overrides={
('Contents','A1'):'MiD 2023 | Comprehensive data reference — English edition',
('Contents','A3'):'English translation of the original workbook. Values, codes, identifiers, filenames and source URLs are retained. Official place names and civic titles remain identifiable. This collection includes MiD aircraft-journey aggregates, broader context and separate external sources. Individual B1 responses still require approved access.',
('Contents','C10'):'All question blocks in the published CATI/CAWI overview: English translations of the questions, options, filters and reference periods.',
('B1 variables','C5'):'Variable label (English translation)',
('B1 value codes','D5'):'Value label (English translation)',
('Survey questions','E5'):'Question wording (English translation)',
('RegioStaR definitions','C5'):'Label (English translation)',
('RegioStaR definitions','D5'):'Context (English translation)',
('RegioStaR definitions','E5'):'Source variable description (English)',
('RegioStaR definitions','A2'):'Official regional typology, federal-state and urban-region codes, with English translations of the Codeplan labels. Municipality membership and its boundary date are separate.',
('Geography field definitions','B5'):'Meaning or label (English)',
('Co-use by age','A5'):'Cohort code',
('Co-use by age','A2'):'Multiple responses. reise = overnight aircraft journeys; tage = aircraft day journeys. Each pair shows a weighted share and unweighted subgroup base. Blank = category not returned. Ages are published bands, not exact birth cohorts.',
('Survey questions','A2'):'English translation of all 125 question blocks from the published German CATI/CAWI overview, PDF pages 6–32. This is not the full routing master. Questionnaire codes may differ from released dataset codes.',
('B1 variables','A2'):'Complete B1 v1.1 variable inventory with English labels. Original variable identifiers and source-file references are retained. H_ID=0 can mean no household assignment; see its value label.',
('B1 value codes','A2'):'Complete B1 v1.1 code lists with English labels. All original codes and source-row references are retained. Empty codes with labels remain as in the source.',
('Airports passenger traffic','E34'):'Published total',
('Airports operations','E34'):'Published total',
}
for (sheet,cell),v in overrides.items():patch(sheet,cell,wb[sheet][cell].value,v,'English edition label')
for ws in wb:
    if ws.title.endswith('full tables'):
        for row in ws:
            for c in row:
                if isinstance(c.value,str) and re.match(r'^(reise|tage|p|w)_.*:t\d+ \| Weight:',c.value):
                    v=c.value.replace('Basis (ungewichtet) = unweighted sample N','Unweighted base = sample N')
                    patch(ws.title,c.coordinate,c.value,v,'English metadata label')
                if c.column==1 and c.value=='Basis':
                    patch(ws.title,c.coordinate,c.value,'Base','Context-specific matrix base label')
                if isinstance(c.value,str) and c.value.startswith('Geschlecht') and ' × ' in c.value:
                    current=patches.get((ws.title,c.coordinate),{}).get('translation',c.value)
                    v=re.sub(r'^Sex\b','Gender',current)
                    patch(ws.title,c.coordinate,c.value,v,'Consistent gender label')

payload={'source_file':inv['source_file'],'source_sha256':inv['source_sha256'],'patches':list(patches.values()),
         'source_strings':len(cat),'mapped_strings':len(maps),'edits_by_sheet':dict(__import__('collections').Counter(p['sheet'] for p in patches.values()))}
from openpyxl.utils import get_column_letter
layouts=[]
for ws in wb:
    widths={get_column_letter(i):ws.column_dimensions[get_column_letter(i)].width for i in range(1,ws.max_column+1)}
    merges=[str(r) for r in ws.merged_cells.ranges]
    changes=[p for p in patches.values() if p['sheet']==ws.title]
    sizes={}
    for p in changes:
        c=ws[p['cell']]; width=widths[c.column_letter] or 13
        merged=next((m for m in ws.merged_cells.ranges if c.coordinate in m),None)
        if merged:
            width=sum(widths[get_column_letter(i)] or 13 for i in range(merged.min_col,merged.max_col+1))
            if merged.max_row>merged.min_row:continue
        old=ws.row_dimensions[c.row].height or 15
        if c.row<5:continue
        size=c.font.sz or 10
        lines=sum(max(1,__import__('math').ceil(len(line)/max(8,width*.86))) for line in p['translation'].split('\n'))
        required=min(409,max(old,__import__('math').ceil((lines*max(14,size*1.35)+9)/8)*8))
        if required>old:sizes[c.row]=max(sizes.get(c.row,old),required)
    layouts.append({'sheet':ws.title,'max_column':ws.max_column,'max_row':ws.max_row,'widths':widths,'row_heights':sizes,'merges':merges})
payload['layouts']=layouts
(R/'english_patches.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf8')
identical=[r for r in cat if maps[r['id']]==r['source']]
(R/'identity_translations_review.json').write_text(json.dumps(identical,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'source_strings':len(cat),'patches':len(patches),'identity_strings':len(identical),'edits_by_sheet':payload['edits_by_sheet']},ensure_ascii=True))

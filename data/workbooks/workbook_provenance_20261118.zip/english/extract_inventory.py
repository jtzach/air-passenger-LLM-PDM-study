from pathlib import Path
import json,re,hashlib
from collections import defaultdict
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'overleaf_upload_20261118/source_material/MiD2023_Comprehensive_Data.xlsx'
wb=load_workbook(SOURCE,read_only=False,data_only=False)
columns={
'Contents':set(range(1,4)),
'Aircraft profiles':{1,3,4,9},'Co-use by age':{2},
'MiD and Munich margins':{1,2,5},
'Survey questions':{2,3,5,6,7,8,9},'Survey answer codes':{3,6,7,8},
'B1 variables':{1,3,4},'B1 value codes':{1,4},'Geography code definitions':{2,4,5},
'RegioStaR definitions':{3,4,5},'Geography field definitions':{2,3,4,6},
'Munich published tables':{1,2,4,7},'Airport dataset catalogue':{2,3,4,5},
'PIP source inventory':{2,4},'Sources':{2,5},
'Airports passenger traffic':set(),'Airports operations':set(),
'Airport lookup':{4,7},'Airport definitions':{2,3,4,7},
'Municipality mobility':{22},'District mobility':{21},'RegioStaR municipalities':set(),
'Query catalogue':set(),
}
geo_cols={'Municipality mobility':{5},'District mobility':{4},'RegioStaR municipalities':{2,8,17}}
matrix={'Overnight full tables','Day journey full tables','Flight frequency full tables','Diary full tables'}
catalog={};cells=[];geo=[];protected=[]
def add(text,sheet,address,group):
    if text not in catalog:catalog[text]={'id':f'T{len(catalog)+1:04d}','source':text,'group':group,'locations':[]}
    item=catalog[text];item['locations'].append(f'{sheet}!{address}')
    # A question phrase is translated with the complete questionnaire context.
    if group=='questionnaire':item['group']=group
    cells.append({'sheet':sheet,'cell':address,'id':item['id'],'source':text})
for ws in wb:
    for row in ws:
        for c in row:
            v=c.value
            if not isinstance(v,str) or not v or c.data_type=='f':continue
            if c.row>=6 and c.column in geo_cols.get(ws.title,set()):
                geo.append({'sheet':ws.title,'cell':c.coordinate,'source':v});continue
            eligible=False
            if ws.title in matrix:
                # Source-query metadata rows are English except the quoted German
                # basis label; they contain identifiers and are handled separately.
                eligible=not (re.match(r'^(reise|tage|p|w)_.*:t\d+ \| Weight:',v))
            elif c.row<=5:
                eligible=True
            elif c.column in columns.get(ws.title,set()):eligible=True
            if not eligible:continue
            # Original source locators/identifiers remain byte-identical.
            if re.search(r'https?://|\.xlsx|\.pdf|\.json|\.html|\.zip',v,re.I):
                protected.append({'sheet':ws.title,'cell':c.coordinate,'source':v});continue
            if re.fullmatch(r'[\d\s.,%+<>\-–]+',v):continue
            if ws.title=='RegioStaR definitions' and c.row>=6:
                typ=ws.cell(c.row,1).value
                if typ=='Stadtregion' and c.column==3 and v!='keine Stadtregion':continue
            group='questionnaire' if ws.title.startswith('Survey ') else 'codebook' if ws.title in {'B1 variables','B1 value codes'} else 'context'
            add(v,ws.title,c.coordinate,group)
for group in ['questionnaire','codebook','context']:
    rows=[{k:v for k,v in r.items() if k!='locations'}|{'examples':r['locations'][:3]} for r in catalog.values() if r['group']==group]
    (ROOT/f'inventory_{group}.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
(ROOT/'cell_inventory.json').write_text(json.dumps({'source_file':str(SOURCE),'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'cells':cells,'geographic_names':geo,'protected_source_locators':protected},ensure_ascii=False),encoding='utf8')
(ROOT/'string_catalogue.json').write_text(json.dumps(list(catalog.values()),ensure_ascii=False),encoding='utf8')
print({g:sum(r['group']==g for r in catalog.values()) for g in ['questionnaire','codebook','context']})
print({'candidate_cells':len(cells),'geographic_name_cells':len(geo),'protected_source_locators':len(protected)})

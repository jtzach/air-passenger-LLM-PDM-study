import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';
const root=path.dirname(fileURLToPath(import.meta.url));
const p=JSON.parse(await fs.readFile(path.join(root,'english_patches.json'),'utf8'));
if(process.env.MID_SOURCE_WORKBOOK)p.source_file=process.env.MID_SOURCE_WORKBOOK;
const hash=createHash('sha256').update(await fs.readFile(p.source_file)).digest('hex');
if(hash!==p.source_sha256)throw new Error('Source workbook changed after inventory');
const incremental=process.argv.includes('--incremental');
let edits=p.patches;
const englishPath=path.join(root,'MiD2023_Comprehensive_Data_EN.xlsx');
if(incremental){
  const previous=JSON.parse(await fs.readFile(path.join(root,'english_patches_previous.json'),'utf8'));
  const old=new Map(previous.patches.map(x=>[`${x.sheet}!${x.cell}`,x]));
  const current=new Set(p.patches.map(x=>`${x.sheet}!${x.cell}`));
  edits=p.patches.filter(x=>old.get(`${x.sheet}!${x.cell}`)?.translation!==x.translation);
  for(const x of previous.patches)if(!current.has(`${x.sheet}!${x.cell}`))edits.push({...x,translation:x.source});
}
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(incremental?englishPath:p.source_file));
const previewDir=path.join(root,'previews');await fs.mkdir(previewDir,{recursive:true});
const bySheet=new Map();
for(const x of edits){if(!bySheet.has(x.sheet))bySheet.set(x.sheet,[]);bySheet.get(x.sheet).push(x);}
for(const [name,patches] of bySheet){
  const s=wb.worksheets.getItem(name),columns=new Map();
  for(const x of patches){
    const [,col,row]=x.cell.match(/^([A-Z]+)(\d+)$/);
    if(!columns.has(col))columns.set(col,[]);columns.get(col).push({...x,row:Number(row)});
  }
  let ranges=0;
  for(const [col,items] of columns){
    items.sort((a,b)=>a.row-b.row);
    let run=[];
    const flush=()=>{
      if(!run.length)return;
      s.getRange(`${col}${run[0].row}:${col}${run.at(-1).row}`).values=run.map(x=>[x.translation]);ranges++;run=[];
    };
    for(const item of items){if(run.length&&item.row!==run.at(-1).row+1)flush();run.push(item);}flush();
  }
  const layout=p.layouts.find(x=>x.sheet===name);
  const affectedRows=new Set(patches.map(x=>Number(x.cell.match(/\d+$/)[0])));
  for(const [row,height] of Object.entries(layout.row_heights))if(!incremental||affectedRows.has(Number(row)))s.getRange(`A${row}`).format.rowHeight=height;
  console.log(`Translated ${name}: ${patches.length} cells, ${ranges} ranges`);
}
wb.recalculate();
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},maxChars:2500});
await fs.writeFile(path.join(root,'formula_inspection.json'),JSON.stringify(errors,null,2));
const view={
'Contents':'A1:C18','Aircraft profiles':'A1:F9','Co-use by age':'A1:G9','MiD and Munich margins':'A1:E9',
'Survey questions':'A1:F8','Survey answer codes':'A1:F9','B1 variables':'A1:E10','B1 value codes':'A1:E10',
'Geography code definitions':'A1:D9','Municipality mobility':'A1:G9','District mobility':'A1:F9',
'RegioStaR municipalities':'A1:F9','RegioStaR definitions':'A1:E9','Geography field definitions':'A1:E9',
'Airport lookup':'A1:G9','Airports passenger traffic':'A1:F9','Airports operations':'A1:F9','Airport definitions':'A1:E9',
'Munich published tables':'A1:E9','Airport dataset catalogue':'A1:D10','PIP source inventory':'A1:D10',
'Overnight full tables':'A1:H15','Day journey full tables':'A1:H15','Flight frequency full tables':'A1:H15','Diary full tables':'A1:H15',
'Query catalogue':'A1:E9','Sources':'A1:D9'
};
for(const s of wb.worksheets.items){
  if(incremental&&!bySheet.has(s.name))continue;
  const range=view[s.name];
  const blob=await wb.render({sheetName:s.name,range,scale:1,format:'png'});
  await fs.writeFile(path.join(previewDir,s.name.replaceAll(' ','_')+'.png'),new Uint8Array(await blob.arrayBuffer()));
}
for(const [name,range,suffix] of [['Survey questions','D6:I9','wording'],['Survey answer codes','E5:I10','answers'],['B1 value codes','A3000:D3006','middle'],['RegioStaR municipalities','I5:Q9','categories']]){
  if(incremental&&!bySheet.has(name))continue;
  const blob=await wb.render({sheetName:name,range,scale:1,format:'png'});
  await fs.writeFile(path.join(previewDir,name.replaceAll(' ','_')+'_'+suffix+'.png'),new Uint8Array(await blob.arrayBuffer()));
}
const dest=path.join(root,'MiD2023_Comprehensive_Data_EN.xlsx');
await (await SpreadsheetFile.exportXlsx(wb)).save(dest);
console.log('Exported '+dest);

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const root=path.dirname(fileURLToPath(import.meta.url));
const d=JSON.parse(await fs.readFile(path.join(root,'intermediate/comprehensive_data.json'),'utf8'));
const wb=Workbook.create(), navy='#173B57', teal='#117C83', pale='#E9F2F4', ink='#21313C';
const views=[], manifest=[];
const previewDir=path.join(root,'previews'); await fs.mkdir(previewDir,{recursive:true});
const col=n=>{let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
const val=x=>x===undefined?null:typeof x==='object'&&x!==null?JSON.stringify(x):x;
function base(s,last,widths){
  s.showGridLines=false;s.tabColor=teal;
  const range=s.getRange(`A1:${col(widths.length-1)}${last}`);
  range.format.font={name:'Arial',size:10,color:ink};
  range.format.wrapText=true;range.format.verticalAlignment='center';range.format.rowHeight=32;
  widths.forEach((w,i)=>s.getRange(`${col(i)}1:${col(i)}${last}`).format.columnWidth=w);
}
function merged(s,range,text,fill,fontColor=ink){
  s.mergeCells(range);const r=s.getRange(range);r.values=[[text]];r.format.fill=fill;r.format.font.color=fontColor;
}
function table(t){
  const s=wb.worksheets.add(t.name), n=t.headers.length, last=t.rows.length+5;
  const widths=t.widths.map((w,i)=>Math.min(w, t.name==='Survey questions'&&i===5?95:95));
  base(s,last,widths);
  let cap=0,acc=0;for(let i=0;i<n;i++){acc+=widths[i];cap=i;if(acc>=140)break;}
  cap=Math.max(1,cap);
  merged(s,`A1:${col(cap)}1`,t.name,navy,'#FFFFFF');s.getRange('A1').format.font={name:'Arial',size:19,bold:true,color:'#FFFFFF'};s.getRange('A1').format.rowHeight=36;
  merged(s,`A2:${col(cap)}2`,t.note||'Published data and source definitions.',pale);s.getRange('A2').format.rowHeight=Math.max(36,Math.ceil((t.note||'').length/(acc*.85))*15+10);
  merged(s,`A3:${col(cap)}3`,'Source: '+t.source,'#F4F7F9');s.getRange('A3').format.rowHeight=36;s.getRange('A3').format.font.color='#526371';
  s.getRange('A4').format.rowHeight=9;
  s.getRange(`A5:${col(n-1)}${last}`).values=[t.headers,...t.rows.map(r=>r.map(val))];
  s.tables.add(`A5:${col(n-1)}${last}`,true,t.name.replace(/[^a-zA-Z0-9]/g,'')+'Data');
  s.getRange(`A5:${col(n-1)}5`).format={fill:teal,font:{bold:true,color:'#FFFFFF'},rowHeight:56,wrapText:true};
  const heights=new Map();
  t.rows.forEach((r,ri)=>{
    const lines=Math.max(...r.map((x,ci)=>String(x??'').split('\n').reduce((a,l)=>a+Math.max(1,Math.ceil(l.length/Math.max(8,widths[ci]*.88))),0)));
    const h=Math.min(409,Math.max(32,Math.ceil((lines*14+9)/8)*8));
    if(h!==32){if(!heights.has(h))heights.set(h,[]);heights.get(h).push(ri+6);}
  });
  for(const [h,rs] of heights)for(const r of rs)s.getRange(`A${r}:${col(n-1)}${r}`).format.rowHeight=h;
  for(const [key,fmt] of Object.entries(t.formats)){
    const c=/^\d+$/.test(key)?col(Number(key)):key;
    const [a,b=a]=c.split(':');s.getRange(`${a}6:${b}${last}`).setNumberFormat(fmt);
  }
  // These are categorical identifiers even when their labels contain only digits.
  t.headers.forEach((h,i)=>{if(/(^Code$|Question ID|Survey variables|^Variable$|^Source query$|SHA256|ags|district_code|state_code|^iata$)/i.test(h))s.getRange(`${col(i)}6:${col(i)}${last}`).setNumberFormat('@');});
  // The renderer parses digit-only strings; zero formats retain the visible code
  // while exported XLSX identifiers remain source text.
  t.headers.forEach((h,i)=>{if(h==='municipality_ags')s.getRange(`${col(i)}6:${col(i)}${last}`).setNumberFormat('00000000');if(h==='district_code')s.getRange(`${col(i)}6:${col(i)}${last}`).setNumberFormat('00000');});
  if(t.name==='RegioStaR municipalities'){
    for(const [key,len] of Object.entries({gem_23:8,gemrs_23:12,vbgemrs_23:9,RegioStaR_Stadtregion:8})){
      const i=t.headers.indexOf(key);s.getRange(`${col(i)}6:${col(i)}${last}`).setNumberFormat('0'.repeat(len));
    }
  }
  if(t.name==='Munich published tables')t.rows.forEach((r,i)=>s.getRange(`C${i+6}`).setNumberFormat(r[3]==='share'?'0.00%':'0.0'));
  if(t.name==='RegioStaR definitions')t.rows.forEach((r,i)=>{if(/^0\d+$/.test(r[1]))s.getRange(`B${i+6}`).setNumberFormat('0'.repeat(r[1].length));});
  s.freezePanes.freezeRows(5);s.freezePanes.freezeColumns(Math.min(2,n));
  views.push({name:t.name,range:`A1:${col(Math.max(cap,Math.min(n-1,4)))}${Math.min(last,9)}`});
  if(t.name==='Survey questions')views.push({name:t.name,range:'D6:I9',suffix:'_wording'});
  if(t.name==='Survey answer codes')views.push({name:t.name,range:'E5:I10',suffix:'_answers'});
  if(t.name==='Airports passenger traffic'||t.name==='Airports operations')views.push({name:t.name,range:'J5:O10',suffix:'_numbers'});
  if(t.name==='B1 value codes')views.push({name:t.name,range:`A${Math.floor(last/2)}:D${Math.floor(last/2)+5}`,suffix:'_middle'});
  manifest.push({sheet:t.name,kind:'table',headerRow:5,firstDataRow:6,lastDataRow:last,columns:n,rows:t.rows.length});
  console.log(`Added ${t.name}: ${t.rows.length}`);
}
const mnames={reise:'Overnight full tables',tage:'Day journey full tables',p:'Flight frequency full tables',w:'Diary full tables'};
function matrices(ds){
  const blocks=d.blocks[ds],s=wb.worksheets.add(mnames[ds]);
  const nc=2+2*Math.max(...blocks.map(b=>b.columns.length));
  const last=5+blocks.reduce((a,b)=>a+b.rows.length+6,0);
  base(s,last,[30,46,...Array(nc-2).fill(17)]);s.tabColor='#428F9B';
  merged(s,'A1:H1',mnames[ds],navy,'#FFFFFF');s.getRange('A1').format.font={name:'Arial',size:19,bold:true,color:'#FFFFFF'};s.getRange('A1').format.rowHeight=36;
  merged(s,'A2:H2','Complete returned matrices, including all comparison groups. Shares use each column’s base. Counts are weighted and rounded except explicitly labelled unweighted bases.',pale);s.getRange('A2').format.rowHeight=44;
  merged(s,'A3:H3','Source: public MiT queries. Match each block’s source file to the Query catalogue for request, retrieval time and checksum. Blank percentages were not returned.','#F4F7F9');s.getRange('A3').format.rowHeight=42;
  let row=5;const locations=[];
  for(const b of blocks){
    const st=row,endc=col(2+b.columns.length*2-1),m=b.meta;
    const age=m.breakdown_info?` | ${m.breakdown_info.label}: ${m.breakdown_info.value}`:'';
    merged(s,`A${row}:H${row}`,`${m.row_label?.trim()||m.row} × ${m.col_label?.trim()||m.col}${age}`,teal,'#FFFFFF');s.getRange(`A${row}`).format.font.bold=true;s.getRange(`A${row}`).format.rowHeight=37;row++;
    merged(s,`A${row}:H${row}`,`${b.id} | Weight: ${m.weight_var} | Column percentages. Count = rounded weighted value; Basis (ungewichtet) = unweighted sample N.`,'#F4F7F9');s.getRange(`A${row}`).format.rowHeight=39;row++;
    s.getRange(`A${row}:B${row+1}`).values=[['Row group','Category'],['','']];
    b.columns.forEach((c,i)=>{
      const a=col(2+i*2),z=col(3+i*2);
      merged(s,`${a}${row}:${z}${row}`,c.label,pale);s.getRange(`${a}${row}`).format.font.bold=true;
      s.getRange(`${a}${row+1}:${z}${row+1}`).values=[['Share','Count / source total']];
    });
    s.getRange(`A${row}:${endc}${row+1}`).format.fill=pale;s.getRange(`A${row}:${endc}${row+1}`).format.font.bold=true;s.getRange(`A${row}`).format.rowHeight=42;s.getRange(`A${row+1}`).format.rowHeight=31;row+=2;
    const first=row;
    const values=b.rows.map(r=>[r.group,r.label,...r.cells.flatMap(c=>[c.percent===undefined?null:c.percent/100,c.text??null])]);
    s.getRange(`A${row}:${endc}${row+values.length-1}`).values=values;
    for(let i=0;i<b.columns.length;i++){
      s.getRange(`${col(2+i*2)}${row}:${col(2+i*2)}${row+values.length-1}`).setNumberFormat('0.0%');
      s.getRange(`${col(3+i*2)}${row}:${col(3+i*2)}${row+values.length-1}`).setNumberFormat('#,##0');
    }
    const baseStart=b.rows.findIndex(r=>r.group==='Basis');
    if(baseStart>=0){const br=s.getRange(`A${row+baseStart}:${endc}${row+values.length-1}`);br.format.fill=pale;br.format.font.bold=true;}
    b.rows.forEach((r,i)=>{
      const rr=row+i;
      const lines=Math.max(Math.ceil((r.label?.length||0)/40),Math.ceil((r.group?.length||0)/26));
      if(lines>2)s.getRange(`A${rr}:${endc}${rr}`).format.rowHeight=lines*14+8;
    });
    locations.push({id:b.id,file:b.file,startRow:st,firstDataRow:first,lastDataRow:first+b.rows.length-1,columns:b.columns.length,rows:b.rows.length});
    row+=values.length+2;
  }
  s.freezePanes.freezeRows(3);s.freezePanes.freezeColumns(2);
  views.push({name:s.name,range:'A1:H14'});
  const flight=blocks[0].columns.findIndex(c=>c.label==='Flugzeug');
  if(flight>=0)views.push({name:s.name,range:`${col(2+flight*2)}7:${col(3+flight*2)}16`,suffix:'_aircraft'});
  manifest.push({sheet:s.name,kind:'matrix',blocks:locations});
  console.log(`Added ${s.name}: ${blocks.length} complete blocks`);
}

const index=wb.worksheets.add('Contents');
const order=['Aircraft profiles','Co-use by age','MiD and Munich margins','Survey questions','Survey answer codes','B1 variables','B1 value codes','Geography code definitions','Municipality mobility','District mobility','RegioStaR municipalities','RegioStaR definitions','Geography field definitions','Airport lookup','Airports passenger traffic','Airports operations','Airport definitions','Munich published tables','Airport dataset catalogue','PIP source inventory'];
const lookup=new Map(d.tables.map(t=>[t.name,t]));
for(const name of order)if(lookup.has(name)){table(lookup.get(name));lookup.delete(name);}
for(const ds of ['reise','tage','p','w'])matrices(ds);
for(const t of lookup.values())table(t);
const ar=d.tables.find(t=>t.name==='Aircraft profiles').rows;
const youngRows=['14-17 Jahre','18-29 Jahre'].map(age=>ar.findIndex(r=>r[0]==='overnight aircraft journeys'&&r[1]==='alter_gr4'&&r[2]===age&&r[3]==='All eligible ages')+6);
if(youngRows.some(r=>r<6))throw new Error('Missing component of young traveller age total');
wb.worksheets.getItem('MiD and Munich margins').getRange('C6').formulas=[[`='Aircraft profiles'!E${youngRows[0]}+'Aircraft profiles'!E${youngRows[1]}`]];

base(index,manifest.length+10,[34,20,110]);index.tabColor=navy;
merged(index,'A1:C2','MiD 2023 | Comprehensive data reference',navy,'#FFFFFF');index.getRange('A1').format.font={name:'Arial',size:22,bold:true,color:'#FFFFFF'};
merged(index,'A3:C4','Public data, original survey questions, released variable codes, geographical classifications and airport statistics. Collected 18 November 2026. Individual B1 response records are not included: access approval is still required.',pale);
index.getRange('A3:C4').format.rowHeight=30;
index.getRange('A6:C6').values=[['Worksheet','Entries','Contents']];index.getRange('A6:C6').format={fill:teal,font:{color:'#FFFFFF',bold:true},rowHeight:34};
const desc={
 'Aircraft profiles':'All extracted aircraft-column estimates; weighted shares and subgroup sample bases.',
 'Co-use by age':'Ground modes reported across the outward and return journey, by age. Not airport access shares.',
 'MiD and Munich margins':'Published indicators side by side, retaining differences in population, time and question wording.',
 'Survey questions':'All question blocks in the published CATI/CAWI overview: German wording, options, filters and reference periods.',
 'Survey answer codes':'Individual response codes, item codes, formats and source ellipses, linked by question ID.',
 'B1 variables':'Complete current B1 v1.1 inventory of variables, labels, measurement and storage format.',
 'B1 value codes':'Complete B1 v1.1 categorical code lists; survey questionnaire codes are shown separately.',
 'Geography code definitions':'RegioStaR, federal-state and other geographic/accessibility codes in B1.',
 'Municipality mobility':'Model-based daily mobility estimates for 1,593 published municipalities, boundary vintage 2023.',
 'District mobility':'Model-based daily mobility estimates for all 400 districts, boundary vintage 2023.',
 'Geography field definitions':'Field meanings, units and definitions for SAE mobility estimates and the RegioStaR municipality lookup.',
 'RegioStaR definitions':'Official codes and labels for regional typologies, federal states and urban regions.',
 'RegioStaR municipalities':'Official municipality-to-regional-type lookup. The source boundary date is retained for every row.',
 'Airport lookup':'28 ADV airport names and IATA codes. No invented city, ICAO or respondent airport assignments.',
 'Airports passenger traffic':'Full Jan–Dec 2023 passenger traffic table for 28 airports and published total, with changes versus 2022.',
 'Airports operations':'Full 2023 airport operations and cargo table, with changes versus 2022.',
 'Airport definitions':'Definitions, units, reporting periods and source pages for airport statistics.',
 'Munich published tables':'Published 2025 age, gender, residence, journey purpose, access and passenger traffic quantities.',
 'Airport dataset catalogue':'14 airport-provided dataset descriptions and availability notes; underlying records not yet supplied.',
 'PIP source inventory':'Public Passenger Insight Platform source descriptions and links provided by that inventory.',
 'Overnight full tables':'Every category and main-mode column in the collected overnight-journey matrices.',
 'Day journey full tables':'Every category and main-mode column in the collected same-day-journey matrices.',
 'Flight frequency full tables':'Participant characteristics and mobility context by reported aircraft-use frequency.',
 'Diary full tables':'Published diary context; public main-mode grouping alone cannot isolate air passengers.',
 'Query catalogue':'Exact request payloads, file references, retrieval times and hashes for the 120 public API queries.',
 'Sources':'Official files, direct URLs, release versions and source coverage.'
};
index.getRange(`A7:C${manifest.length+6}`).values=manifest.map(m=>[m.sheet,m.kind==='matrix'?`${m.blocks.length} tables`:m.rows,desc[m.sheet]||lookup.get(m.sheet)?.note||'Official geographical classification table.']);
index.getRange(`A7:C${manifest.length+6}`).format.rowHeight=42;
index.tables.add(`A6:C${manifest.length+6}`,true,'ContentsIndex');index.freezePanes.freezeRows(6);
views.unshift({name:'Contents',range:`A1:C${Math.min(20,manifest.length+6)}`});
wb.recalculate();
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},maxChars:3000});
await fs.writeFile(path.join(root,'intermediate/workbook_inspection.json'),JSON.stringify(errors,null,2));
await fs.writeFile(path.join(root,'intermediate/workbook_manifest.json'),JSON.stringify(manifest,null,2));
const check=await wb.inspect({kind:'region',sheetId:'Aircraft profiles',range:'A5:H8',tableMaxRows:4,tableMaxCols:8,maxChars:2200});console.log(check.ndjson);
for(const v of views){
  const preview=await wb.render({sheetName:v.name,range:v.range,scale:1,format:'png'});
  const filename=v.name.replaceAll(' ','_')+(v.suffix||'')+'.png';
  await fs.writeFile(path.join(previewDir,filename),new Uint8Array(await preview.arrayBuffer()));
  console.log('Rendered '+filename);
}
await (await SpreadsheetFile.exportXlsx(wb)).save(path.join(root,'MiD2023_Comprehensive_Data.xlsx'));
console.log('Exported MiD2023_Comprehensive_Data.xlsx');

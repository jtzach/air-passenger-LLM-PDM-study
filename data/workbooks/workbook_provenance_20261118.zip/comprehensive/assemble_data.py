"""Assemble source data, questionnaires and classifications for the comprehensive workbook."""
from pathlib import Path
import json, re, html, hashlib, shutil
from openpyxl import load_workbook
ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/'mid2023_aircraft_20261118'
APP=ROOT.parent/'mid2023_b1_application_20261118'
OUT=ROOT/'intermediate';OUT.mkdir(exist_ok=True)
def read(p): return json.loads(Path(p).read_text(encoding='utf8'))
tables=[]
def add(name,headers,rows,widths=None,formats=None,note='',source=''):
    tables.append({'name':name,'headers':headers,'rows':rows,'widths':widths or [24]*len(headers),'formats':formats or {},'note':note,'source':source})

air=read(ROOT/'mit_sources/normalized_aircraft.json')
add('Aircraft profiles',['Cohort','Variable','Category','Age stratum','Weighted share','Unweighted base','Weighted base','Weighted cell count','Response type','Source query','Table number'],
    [[r['cohort'],r['variable'],r['category'].strip(),r['breakdown_category'] or 'All eligible ages',None if r['percent'] is None else r['percent']/100,r['base_unweighted'],r['base_weighted_rounded'],r['weighted_count_rounded'],'Multiple responses' if r['multiple_response'] else 'Single response',r['source_file'],r['table_index']] for r in air],
    [28,25,45,22,17,18,18,20,23,62,14],{'E':'0.0%','F:H':'#,##0'},
    'Published aggregate cells, not individual passengers. Use each row’s base. Ground modes indicate outward/return co-use, not airport access.','MiT public tables; exact requests in Query catalogue')

# Compact co-use matrix; every estimate is a direct returned source cell.
ages=['All eligible ages','14-17 Jahre','18-29 Jahre','30-39 Jahre','40-49 Jahre','50-59 Jahre','60-64 Jahre','65-74 Jahre','75-79 Jahre','80 Jahre und älter']
co=[]
for ds in ['reise','tage']:
    subset=[r for r in air if r['dataset']==ds and r['multiple_response']]
    modes=list(dict.fromkeys(r['category'].strip() for r in subset))
    for mode in modes:
        vals=[]
        for age in ages:
            rr=[r for r in subset if r['category'].strip()==mode and (r['breakdown_category'] or ages[0])==age]
            vals.extend([rr[0]['percent']/100 if rr else None,rr[0]['base_unweighted'] if rr else None])
        co.append([ds,mode]+vals)
coheads=['Cohort','Co-used mode']+[a+suffix for a in ages for suffix in [' share',' base N']]
coformats={}
for i in range(10):coformats[str(2+2*i)]='0.0%';coformats[str(3+2*i)]='#,##0'
add('Co-use by age',coheads,co,[16,36]+[19,16]*10,coformats,'Multiple responses. Each pair shows weighted share and unweighted subgroup base. Blank = category not returned for that stratum. Ages are published bands, not exact birth cohorts.','MiT mode-by-main-mode queries, with and without age breakdown')

# Full official B1 v1.1 dictionary; all variables and all code rows, not a selected shortlist.
cb_path=next((APP/'sources/B1_v1_1_reference').glob('*.xlsx'))
wb=load_workbook(cb_path,read_only=True,data_only=True)
variables=[];codes=[]
for ws in wb:
    current=None
    for n,row in enumerate(ws.iter_rows(values_only=True),1):
        if row[1] and row[1]!='Variable':
            current=[ws.title,str(row[1]),str(row[2] or ''),str(row[5] or ''),str(row[6] or ''),n,cb_path.name]
            variables.append(current)
        if current and (row[3] is not None or row[4] is not None):
            code='' if row[3] is None else str(row[3])
            codes.append([ws.title,current[1],code,str(row[4] or ''),n,cb_path.name])
wb.close()
add('B1 variables',['B1 table','Variable','Exact source label','Measurement','Storage format','Source row','Codebook'],variables,[24,28,82,21,18,15,58],note='Complete released B1 v1.1 variable inventory. Survey question wording and questionnaire codes are separate sheets. H_ID=0 can mean no household assignment; see its value label.',source='MiD2023_Codepläne_B1_Standard_v1.1.xlsx; exact B1 offer 897527161045086208')
add('B1 value codes',['B1 table','Variable','Code','Exact value label','Source row','Codebook'],codes,[24,28,16,105,15,58],note='Complete code lists from the released v1.1 codebook. Empty codes with labels are retained as in the source.',source='MiD2023_Codepläne_B1_Standard_v1.1.xlsx')
vlabels={(v[0],v[1]):v[2] for v in variables}
geo_vars={v[1] for v in variables if v[1].startswith(('Regio','BLAND','GK','kk','gk','rtyp')) or any(s in v[2].lower() for s in ['raumtyp','gemeind','haltestell','wohnort','nahverkehrs','bahnhof','siedlungs','zentralität','ländlich','stadtregion'])}
geoc=[];seen=set()
for r in codes:
    key=(r[1],r[2],r[3])
    if r[1] in geo_vars and key not in seen:
        geoc.append([r[1],vlabels.get((r[0],r[1]),''),r[2],r[3],r[0],r[4]]);seen.add(key)
add('Geography code definitions',['Variable','Classification or attribute','Code','Meaning','B1 source table','Codebook row'],geoc,[28,75,15,100,25,16],note='Meaning of geographical classifications available in B1. These do not identify a respondent’s city or airport.',source='Official B1 v1.1 codebook')

q=read(ROOT/'questionnaire/questions.json');opts=read(ROOT/'questionnaire/answer_options.json')
add('Survey questions',['Question ID','Section','Topic','Survey variables','Question wording in German','Answer options or format','Module','Eligibility stated in overview','Reference period','PDF pages','Internal overview pages','Source'],
    [[r['question_id'],r['section'],r['field_label'],r['variable_raw'],r['question_text'],r['answer_options'],r['module'],r['universe_filter'],r['reference_period'],', '.join(map(str,r['pdf_pages'])),', '.join(map(str,r['overview_pages'])),r['source_file']] for r in q],
    [25,34,32,38,90,115,18,95,60,16,19,65],note='All 125 question blocks from the published CATI/CAWI overview, PDF pages 6–32. The overview is not the complete routing master. Questionnaire codes may differ from released dataset codes.',source='infas_ErgänzendeStudienunterlagen_MiD2023_7555.pdf')
add('Survey answer codes',['Question ID','Survey variables','Section','Order','Code','Answer label or response format','Qualifier','Entry type','PDF pages'],
    [[r['question_id'],r['variable_raw'],r['section'],r['option_order'],r['code'],r['answer_label'],r['qualifier'],r['option_kind'],', '.join(map(str,r['pdf_pages']))] for r in opts],
    [25,38,36,12,14,100,45,28,16],note='All 574 response-code, item-code and open-format entries. Source ellipses are retained; intermediate scale labels are not invented.',source='Published question overview; linked by Question ID')

# Full source query matrices are preserved in separate dataset sheets by the JS builder.
queries=read(ROOT/'mit_sources/successful_queries.json');blocks={d:[] for d in ['reise','tage','p','w']}
query_register=[]
for qr in queries:
    path=ROOT/'mit_sources'/qr['filename'];prov=read(str(path)+'.provenance.json')
    for ti,t in enumerate(read(path),1):blocks[qr['dataset']].append({'id':path.stem+f':t{ti}','file':path.name,**t})
    query_register.append([path.name,qr['dataset'],qr['row'],qr['col'],qr['breakdown_by'] or '',qr['tables'],prov['url'],json.dumps(prov.get('request'),ensure_ascii=False),'UTC | '+prov['retrieved_utc'],prov['sha256']])
add('Query catalogue',['Source query','Dataset','Row variable','Column variable','Breakdown','Tables returned','Endpoint','Exact POST request','Retrieved UTC','SHA256'],query_register,[60,16,55,27,24,17,70,120,34,74],note='120 successful public queries. Counts and percentages in the complete matrix sheets preserve all returned main-mode/frequency groups, not just the aircraft column.',source='MiT public API used by its own website')

# Municipality and district context, retaining all original numeric precision.
reg_defs=ROOT/'geography/regiostar_code_definitions.json'
if reg_defs.exists():
    g=read(reg_defs);cols=g['columns']
    definition_rows=g['rows'].copy()
    for extra in ['regiostar_state_definitions.json','regiostar_urban_region_definitions.json']:
        if (ROOT/'geography'/extra).exists():definition_rows+=read(ROOT/'geography'/extra)['rows']
    add('RegioStaR definitions',cols,[[r.get(c) for c in cols] for r in definition_rows],[25,18,72,60,70,22,16,95,65],note='Official regional typology, federal-state and urban-region codes and German labels from the reference workbook Codeplan. Municipality membership and its boundary date are separate.',source=g['source_url'])
reg_members=ROOT/'geography/regiostar_membership_2023.json'
if reg_members.exists():
    g=read(reg_members)
    cols=['gem_23','name_23','boundary_vintage','bev_23','fl_23','gemrs_23','vbgemrs_23','vbgnam_23','RegioStaR2','RegioStaR4','RegioStaR17','RegioStaR7','RegioStaR5','RegioStaRGem7','RegioStaRGem5','RegioStaR_Stadtregion','RegioStaR_NameStadtregion','source_row']
    add('RegioStaR municipalities',cols,[[r.get(c) for c in cols] for r in g['rows']],[18,48,22,21,20,23,23,48,18,18,18,18,18,20,20,26,48,16],{'D':'#,##0','E':'0.00'},
        'Full 2023 reference: 10,978 municipality/municipality-free-area records. gem_23 = AGS; gemrs_23 = ARS; bev_23 = population; fl_23 = area km². Boundary 31 Dec 2023. B1 does not provide a respondent municipality key.',g['source_url'])
for filename,name,idcols in [('municipality_sae.json','Municipality mobility',3),('district_sae.json','District mobility',2)]:
    g=read(ROOT/'geography'/filename)
    cols=g['columns']; formats={}
    for i,c in enumerate(cols):
        if c.endswith('_pct'):formats[str(i)]='0.0%'
        elif c in [n['field'] for n in g['numeric_fields']]:formats[str(i)]='0'
    rows=[]
    for r in g['rows']:
        rows.append([r.get(c)/100 if c.endswith('_pct') and isinstance(r.get(c),(int,float)) else r.get(c) for c in cols])
    # Publisher requests whole-number display for small-area estimates.
    for k in list(formats):
        if formats[k]=='0.0%':formats[k]='0%'
    add(name,cols,rows,[18 if 'code' in c or 'ags' in c else 37 if 'name' in c else 22 for c in cols],formats,
        'Official model-based estimates for all residents, not aircraft-specific observations. Boundary vintage 31 Dec 2023. B1 has no municipality/district join key. '+g['coverage'],g['source_url'])
    if filename=='municipality_sae.json':
        defs=[[n['field'],n['source_label'],n['unit'],'SAE model estimate; original precision retained, whole-number display requested by publisher.',g['source_file'],'Municipality and district SAE',g['source_url']] for n in g['numeric_fields']]
        fd=ROOT/'geography/regiostar_2023_field_dictionary.json'
        if fd.exists():
            f=read(fd);defs += [[r.get(c) for c in f['columns']] for r in f['rows']]
        add('Geography field definitions',['Field','Meaning or original label','Unit or type','Definition','Source file','Source table','URL'],defs,[45,70,35,95,65,42,95],note='Field definitions for SAE local mobility estimates and the 2023 RegioStaR municipality reference. Category-code labels are in RegioStaR definitions.',source='Official SAE workbooks and RegioStaR reference workbook; source per row')

for file,name in [('airport_passengers_2023.json','Airports passenger traffic'),('airport_operations_2023.json','Airports operations')]:
    rr=read(ROOT/'airports'/file); cols=list(rr[0]);cols=[c for c in cols if not c.endswith('_raw')]
    rows=[[r.get(c)/100 if c.endswith('_pct') and isinstance(r.get(c),(int,float)) else r.get(c+'_raw') if c.endswith('_pct') and r.get(c) is None else r.get(c) for c in cols] for r in rr]
    fm={str(i):'0.0%' if c.endswith('_pct') else '#,##0' for i,c in enumerate(cols) if isinstance(rr[0].get(c),(int,float)) and c not in ['year','source_page']}
    add(name,cols,rows,[48 if 'name' in c else 75 if c=='source_url' else 25 for c in cols],fm,
        'Calendar year 2023, 28 ADV reporting airports plus a marked published total. '+('Passenger movements are not unique people. ' if 'passenger' in file else 'Aircraft movements, cargo tonnes and traffic units use distinct units. ')+'Percent changes are versus 2022; published bounds such as >1000% are retained. See Airport definitions.',rr[0]['source_url'])
al=read(ROOT/'airports/airport_lookup.json')
add('Airport lookup',list(al[0]),[[r.get(c) for c in al[0]] for r in al],[14,38,14,67,20,15,85,95],note='Source-listed names and IATA codes only. No ICAO or municipality assignment was supplied; blanks are intentional. No respondent-to-airport link is established in this workbook.',source=al[0]['source_url'])
ad=read(ROOT/'airports/airport_metric_definitions.json')
add('Airport definitions',list(ad[0]),[[r.get(c) for c in ad[0]] for r in ad],[48,75,28,105,20,15,18,90],source=ad[0]['source_url'])

# Munich published quantities and categorical details, with exact scope and source pages.
muc=read(PREV/'muc_sources/muc_benchmark_rows.json')
mr=[[r['metric'],r['category'],r['proportion'],'share',2025,r['printed_page'],r['denominator_qualifications'],r['source_url']] for r in muc]
mu=muc[0]['source_url']
for cat,val in [('Visiting friends and relatives',.22),('Leisure holidays relaxation city or cultural trip',.51),('Combined private and business',.02),('Business appointment or meeting',.17),('Seminar workshop congress or other business',.09)]:
    mr.append(['Detailed journey purpose',cat,val,'share',2025,11,'Published rounded detailed categories sum to 101%; preserve rounding. Categories require harmonisation with MiD R_ZWECK.',mu])
for cat,val in [('Male',.52),('Female',.48),('Non-binary',.0003)]:mr.append(['Gender',cat,val,'share',2025,12,'Published rounded gender shares; may differ from MiD sex coding.',mu])
for cat,val in [('Total passengers',43.4),('Long-haul passengers',8.9),('Continental passengers',28.4),('Domestic German passengers',6.1)]:mr.append(['Passenger volume',cat,val,'million passenger movements',2025,10,'Annual airport traffic, not unique residents or survey respondent counts.',mu])
add('Munich published tables',['Metric','Category','Published value','Unit','Year','Printed page','Population or definition note','Source URL'],mr,[34,55,19,30,12,17,115,95],note='Published Munich 2025 survey/traffic quantities. Separate age and access marginals do not supply an age-by-access joint table.',source=mu)

# Exact published numbers put side by side; no claim of matched sampling frames.
def rec(var,cat):return next(r for r in air if r['dataset']=='reise' and r['variable']==var and r['category'].strip()==cat and not r['breakdown_category'])
young=sum(r['percent'] for r in air if r['dataset']=='reise' and r['variable']=='alter_gr4' and r['category'] in ['14-17 Jahre','18-29 Jahre'])/100
comp=[['Younger travellers','MiD 14–29; Munich ≤29',young,.23,'Age coverage differs; MiD journey module starts at 14.'],
      ['Business purpose','dienstlich/geschäftlich versus Business',rec('R_ZWECK','dienstlich / geschäftlich')['percent']/100,.27,'MiD overnight aircraft journeys versus all surveyed airport passenger journey types.'],
      ['Ages 50–59','Same published age interval',rec('alter_gr4','50-59 Jahre')['percent']/100,.18,'Different population and survey year.'],
      ['Visiting friends or relatives','MiD family/friends/acquaintances versus MUC VFR',rec('R_ZWECK','Besuch von Familie / Verwandten / Freunden/Freundinnen / Bekannten')['percent']/100,.22,'Purpose wording, residence coverage and same-day/overnight mix differ.'],
      ['Holiday or leisure','MiD holiday/short holiday versus broader MUC leisure',rec('R_ZWECK','Urlaub, Kurzurlaub oder Ähnliches')['percent']/100,.51,'Not fully harmonised categories.']]
add('MiD and Munich margins',['Indicator','Category alignment','MiD overnight aircraft','Munich 2025','Comparability note'],comp,[35,70,24,22,115],{'C:D':'0.0%'},'Descriptive side-by-side figures, not tests of contradiction or equivalence. MiD German residents, 2023/24 fieldwork; MUC includes foreign residents.','MiT aircraft columns and Munich annual report pp11–12')

# Airport dataset catalogue supplied by the user. Descriptions are not received observations.
overview=ROOT.parents[1]/'overleaf_project/source_material/20260825_MUC_Dataset_Overview.xlsx'
ow=load_workbook(overview,read_only=True,data_only=True); ors=list(ow.active.iter_rows(values_only=True));ow.close()
add('Airport dataset catalogue',['Number','Dataset','Description','Published or supplied detail','Access status','Source file'],[[r[0],r[1],r[2],r[3],'Catalogue description; underlying records not received',overview.name] for r in ors[1:] if r[1]],[13,40,85,110,57,59],note='Original airport-provided availability catalogue. Potential-use brainstorming column omitted. Availability is subject to airport confirmation.',source=overview.name)

pip=(PREV/'muc_sources/MUC_PIP_sources.html').read_text(encoding='utf8')
lis=re.findall(r'<li\b[^>]*>(.*?)</li>',pip,re.S|re.I)
piprows=[]
for n,item in enumerate(lis,1):
    value=html.unescape(re.sub('<[^>]+>',' ',item));value=' '.join(value.split())
    links=re.findall(r'href=[\"\x27]([^\"\x27]+)',item)
    if value:piprows.append([n,value,'; '.join(links),'July 2026','https://pip.munich-airport.de/sources'])
if piprows:add('PIP source inventory',['Entry','Published source description','Links supplied on page','Inventory date','Inventory URL'],piprows,[13,140,80,22,75],note='Published source inventory, not the underlying survey data or computed personas.',source='https://pip.munich-airport.de/sources')

sources=[['MID_QUESTIONS','Published questionnaires and processing definitions','infas_ErgänzendeStudienunterlagen_MiD2023_7555.pdf','https://www.mobilitaet-in-deutschland.de/pdf/infas_Erg%C3%A4nzendeStudienunterlagen_MiD2023_7555.pdf','Published overview pp6–32; source routing limitations apply'],
 ['MID_B1_V11','Current released data dictionary',cb_path.name,'https://mobilithek.info/offers/897527161045086208','Version1.1; some fields differ from questionnaire and earlier handbook'],
 ['MID_B1_RELEASE','Release notes','Hinweise zu den Datensätzen in der Mobilithek und zum Nutzerhandbuch.pdf','https://mobilithek.info/offers/897527161045086208','28 Aug2025: some variables aggregated/deleted; household assignment retained for first6members; others can have H_ID0'],
 ['MUC_OVERVIEW','User-supplied airport dataset catalogue',overview.name,'','Descriptions only; original supplied file'],
 ['MUC_REPORT','Munich annual report2025','MUC_annual_traffic_report_2025.pdf',mu,'Printed pp10–12; verified source PDF'],
 ['MUC_PIP','Persona source inventory','MUC_PIP_sources.html','https://pip.munich-airport.de/sources','Inventory date July2026'],
 ['ADV2023','German reporting airports2023','ADV_December_2023.pdf',al[0]['source_url'],'28 airports; annual Jan–Dec tables pp12–13; definitions pp14–16']]
for fn in ['district_sae.json','municipality_sae.json']:
    g=read(ROOT/'geography'/fn);sources.append([g['source_id'],'MiD small-area model estimates',g['source_file'],g['source_url'],g['coverage']+' Boundary2023-12-31.'])
if reg_defs.exists():
    g=read(reg_defs);sources.append(['REGIOSTAR_DEFS','Official regional typology definitions',g['source_file'],g['source_url'],'Seven classification schemes; labels and codes, not municipality membership.'])
if reg_members.exists():
    g=read(reg_members);sources.append(['REGIOSTAR_2023','Official municipality regional typology lookup',g['source_file'],g['source_url'],'ReferenzGebietsstand2023; boundary2023-12-31; full10,978 reference entries including municipality-free areas.'])
add('Sources',['Source ID','Source type','Original file','URL','Version or coverage'],sources,[26,42,80,110,115],note='Source references only. Exact MiT query payloads and hashes are in Query catalogue. Research plans, application drafts and detailed methods are stored outside this workbook.')
payload={'tables':tables,'blocks':blocks,'counts':{'air_cells':len(air),'questions':len(q),'answers':len(opts),'variables':len(variables),'value_codes':len(codes),'queries':len(queries),'matrix_tables':sum(len(v) for v in blocks.values())}}
(OUT/'comprehensive_data.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf8')
print(json.dumps(payload['counts']))

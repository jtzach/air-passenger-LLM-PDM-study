"""Read an exported XLSX and compare every source cell; never writes the workbook."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sys

import openpyxl
from openpyxl.utils import get_column_letter


ROOT = Path(__file__).resolve().parent
MATRIX_NAMES = {
    "reise": "Overnight full tables",
    "tage": "Day journey full tables",
    "p": "Flight frequency full tables",
    "w": "Diary full tables",
}
ERROR_LITERALS = {
    "#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A", "#NUM!",
    "#NULL!", "#SPILL!", "#CALC!", "#GETTING_DATA",
}


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def scalar(value):
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return value


def equal(actual, expected):
    if expected in (None, ""):
        return actual in (None, "")
    if isinstance(expected, bool):
        return type(actual) is bool and actual == expected
    if isinstance(expected, (int, float)):
        return (isinstance(actual, (int, float)) and not isinstance(actual, bool)
                and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12))
    if isinstance(actual, datetime) and isinstance(expected, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", expected):
        return actual == datetime.fromisoformat(expected)
    return type(actual) is type(expected) and actual == expected


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workbook", type=Path, default=ROOT / "MiD2023_Comprehensive_Data.xlsx")
    parser.add_argument("--data", type=Path, default=ROOT / "intermediate/comprehensive_data.json")
    parser.add_argument("--manifest", type=Path, default=ROOT / "intermediate/workbook_manifest.json")
    parser.add_argument("--output", type=Path, default=ROOT / "intermediate/export_validation.json")
    args = parser.parse_args()
    for path in (args.workbook, args.data, args.manifest):
        if not path.is_file():
            print(f"Required file is not yet available: {path}")
            return 2

    data = json.loads(args.data.read_text(encoding="utf-8"))
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    wb = openpyxl.load_workbook(args.workbook, read_only=False, data_only=False)
    cached_wb = openpyxl.load_workbook(args.workbook, read_only=False, data_only=True)
    findings = []
    checks = Counter()
    details = {"tables": [], "matrices": [], "geography": []}
    aircraft_rows = next(t["rows"] for t in data["tables"] if t["name"] == "Aircraft profiles")
    young_rows = [next(i+6 for i, row in enumerate(aircraft_rows)
                       if row[:4] == ["overnight aircraft journeys", "alter_gr4", age, "All eligible ages"])
                  for age in ("14-17 Jahre", "18-29 Jahre")]
    allowed_formulas = {
        ("MiD and Munich margins", "C6"):
        f"='Aircraft profiles'!E{young_rows[0]}+'Aircraft profiles'!E{young_rows[1]}"
    }

    def problem(kind, **context):
        findings.append({"kind": kind, **context})

    def check_cell(ws, row, col, expected, kind="source_value"):
        cell = ws.cell(row, col)
        actual = cached_wb[ws.title].cell(row, col).value if cell.data_type == "f" else cell.value
        if isinstance(actual, datetime) and isinstance(expected, str) and equal(actual, expected):
            checks["iso_date_as_equivalent_native_date"] += 1
        checks[kind] += 1
        if not equal(actual, scalar(expected)):
            problem(kind, sheet=ws.title, cell=cell.coordinate,
                    expected=scalar(expected), actual=actual, data_type=cell.data_type)
        return cell

    expected_sheets = {"Contents"} | {t["name"] for t in data["tables"]}
    expected_sheets |= {MATRIX_NAMES[ds] for ds in data["blocks"]}
    if set(wb.sheetnames) != expected_sheets:
        problem("sheet_coverage", missing=sorted(expected_sheets-set(wb.sheetnames)),
                unexpected=sorted(set(wb.sheetnames)-expected_sheets))
    manifest_map = {m["sheet"]: m for m in manifest}
    if len(manifest_map) != len(manifest):
        problem("duplicate_manifest_sheet")
    if set(manifest_map) != expected_sheets - {"Contents"}:
        problem("manifest_coverage", expected=sorted(expected_sheets-{"Contents"}),
                actual=sorted(manifest_map))

    for table in data["tables"]:
        name, headers, rows = table["name"], table["headers"], table["rows"]
        if name not in wb.sheetnames:
            continue
        ws = wb[name]
        expected_manifest = {
            "sheet": name, "kind": "table", "headerRow": 5, "firstDataRow": 6,
            "lastDataRow": len(rows)+5, "columns": len(headers), "rows": len(rows),
        }
        if manifest_map.get(name) != expected_manifest:
            problem("table_manifest", sheet=name, expected=expected_manifest,
                    actual=manifest_map.get(name))
        check_cell(ws, 1, 1, name, "title")
        check_cell(ws, 2, 1, table.get("note") or "Published data and source definitions.", "note")
        check_cell(ws, 3, 1, "Source: " + str(table["source"]), "source_label")
        for c, value in enumerate(headers, 1):
            check_cell(ws, 5, c, value, "header")
        for r, row in enumerate(rows, 6):
            if len(row) != len(headers):
                problem("source_row_width", sheet=name, row=r, expected=len(headers), actual=len(row))
            for c, value in enumerate(row, 1):
                check_cell(ws, r, c, value, "table_value")

        # Identifiers must retain their literal digits and leading zeroes.
        geo_columns = [i for i, h in enumerate(headers) if
                       re.search(r"(^|_)(ags|district_code|state_code)($|_)", str(h), re.I)
                       or (name == "Geography code definitions" and h == "Code")
                       or (name.startswith("RegioStaR") and
                           re.search(r"(code|schl|regiostar|gem_?id|ars|^gem_\d|^gemrs_|^vbgemrs_)", str(h), re.I))]
        geo_checked = 0
        for c in geo_columns:
            for r, row in enumerate(rows, 6):
                value = row[c]
                if value in (None, ""):
                    continue
                cell = ws.cell(r, c+1)
                geo_checked += 1
                checks["geographic_identifier"] += 1
                if not isinstance(value, str):
                    problem("geography_source_not_text", sheet=name, cell=cell.coordinate, expected=value)
                if not isinstance(cell.value, str) or cell.data_type not in ("s", "inlineStr"):
                    problem("geography_export_not_text", sheet=name, cell=cell.coordinate,
                            actual=cell.value, data_type=cell.data_type)
        if geo_columns:
            details["geography"].append({"sheet": name, "columns": [headers[i] for i in geo_columns],
                                         "identifiers_checked": geo_checked})
        details["tables"].append({"sheet": name, "rows": len(rows), "columns": len(headers),
                                  "source_cells_checked": len(rows)*len(headers)})

    query_table = next(t for t in data["tables"] if t["name"] == "Query catalogue")
    query_files = {row[query_table["headers"].index("Source query")] for row in query_table["rows"]}
    block_ids = set()
    for ds, blocks in data["blocks"].items():
        name = MATRIX_NAMES[ds]
        if name not in wb.sheetnames:
            continue
        ws = wb[name]
        actual_blocks = manifest_map.get(name, {}).get("blocks", [])
        expected_locations = []
        start = 5
        for b in blocks:
            columns, rows = b["columns"], b["rows"]
            first = start+4
            location = {"id": b["id"], "file": b["file"], "startRow": start,
                        "firstDataRow": first, "lastDataRow": first+len(rows)-1,
                        "columns": len(columns), "rows": len(rows)}
            expected_locations.append(location)
            if b["id"] in block_ids:
                problem("duplicate_block_id", id=b["id"])
            block_ids.add(b["id"])
            if b["file"] not in query_files:
                problem("matrix_source_absent_from_catalogue", id=b["id"], file=b["file"])
            meta = b["meta"]
            breakdown = meta.get("breakdown_info")
            age = f" | {breakdown['label']}: {breakdown['value']}" if breakdown else ""
            row_label = (meta.get("row_label") or "").strip() or meta["row"]
            col_label = (meta.get("col_label") or "").strip() or meta["col"]
            check_cell(ws, start, 1, f"{row_label} × {col_label}{age}", "matrix_title")
            check_cell(ws, start+1, 1,
                       f"{b['id']} | Weight: {meta['weight_var']} | Column percentages. Count = rounded weighted value; Basis (ungewichtet) = unweighted sample N.",
                       "matrix_source_id")
            check_cell(ws, start+2, 1, "Row group", "matrix_header")
            check_cell(ws, start+2, 2, "Category", "matrix_header")
            for i, column in enumerate(columns):
                c = 3+2*i
                check_cell(ws, start+2, c, column["label"], "matrix_header")
                check_cell(ws, start+3, c, "Share", "matrix_header")
                check_cell(ws, start+3, c+1, "Count / source total", "matrix_header")
            for i, row in enumerate(rows):
                r = first+i
                check_cell(ws, r, 1, row.get("group"), "matrix_category")
                check_cell(ws, r, 2, row.get("label"), "matrix_category")
                if len(row["cells"]) != len(columns):
                    problem("matrix_source_width", id=b["id"], row=i,
                            actual=len(row["cells"]), expected=len(columns))
                for j, cell in enumerate(row["cells"]):
                    pct = cell.get("percent")
                    check_cell(ws, r, 3+2*j, pct/100 if pct is not None else None, "matrix_share")
                    check_cell(ws, r, 4+2*j, cell.get("text"), "matrix_count_or_total")
                    if "%" not in ws.cell(r, 3+2*j).number_format:
                        problem("matrix_share_format", sheet=name, cell=ws.cell(r,3+2*j).coordinate)
            start += len(rows)+6
        if actual_blocks != expected_locations:
            problem("matrix_manifest_locations", sheet=name,
                    expected=expected_locations, actual=actual_blocks)
        details["matrices"].append({"sheet": name, "blocks": len(blocks),
                                   "rows": sum(len(b["rows"]) for b in blocks)})

    if "Contents" in wb.sheetnames:
        ws = wb["Contents"]
        for i, entry in enumerate(manifest, 7):
            check_cell(ws, i, 1, entry["sheet"], "contents_sheet")
            count = f"{len(entry['blocks'])} tables" if entry["kind"] == "matrix" else entry["rows"]
            check_cell(ws, i, 2, count, "contents_count")

    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is None:
                    continue
                checks["nonempty_cell_scan"] += 1
                if cell.data_type == "e" or (isinstance(cell.value, str) and cell.value in ERROR_LITERALS):
                    problem("error_cell", sheet=ws.title, cell=cell.coordinate, value=cell.value)
                if cell.data_type == "f":
                    expected_formula = allowed_formulas.get((ws.title, cell.coordinate))
                    checks["formula"] += 1
                    if cell.value != expected_formula:
                        problem("unexpected_formula_in_static_data", sheet=ws.title,
                                cell=cell.coordinate, formula=cell.value)
                    cached = cached_wb[ws.title][cell.coordinate]
                    if cached.data_type == "e" or cached.value is None:
                        problem("formula_cache_error_or_missing", sheet=ws.title,
                                cell=cell.coordinate, value=cached.value)
                if isinstance(cell.value, str) and "\ufffd" in cell.value:
                    problem("unicode_replacement", sheet=ws.title, cell=cell.coordinate)

    for (sheet, coordinate), formula in allowed_formulas.items():
        if sheet in wb.sheetnames and wb[sheet][coordinate].value != formula:
            problem("required_formula_missing", sheet=sheet, cell=coordinate,
                    expected=formula, actual=wb[sheet][coordinate].value)

    result = {
        "status": "pass" if not findings else "fail",
        "validated_utc": datetime.now(timezone.utc).isoformat(),
        "workbook": str(args.workbook.resolve()),
        "workbook_sha256": sha256(args.workbook),
        "input_data_sha256": sha256(args.data),
        "manifest_sha256": sha256(args.manifest),
        "source_counts": data.get("counts"),
        "sheet_count": len(wb.sheetnames), "checks": dict(checks),
        "details": details, "finding_count": len(findings), "findings": findings,
        "scope": "Read-only cell-by-cell export comparison. No workbook values or styles changed. Visual layout and substantive validity of external source publications are outside this check.",
    }
    wb.close()
    cached_wb.close()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps({"status": result["status"], "sheets": result["sheet_count"],
                      "checks": result["checks"], "finding_count": len(findings),
                      "output": str(args.output)}, ensure_ascii=False))
    if findings:
        print(json.dumps(findings[:12], ensure_ascii=False, indent=2, default=str))
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main())

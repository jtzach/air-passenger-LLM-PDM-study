# Sources and processing record

Prepared 18 November 2026. Scope: public evidence for aircraft use by residents of Germany in MiD 2023, whose fieldwork ran April 2023–July 2024. This is not a census of passengers at German airports. The workbook is an aggregate research resource; it contains no licensed respondent microdata.

## 1. Files downloaded and their use

The authoritative publication catalogue is <https://www.mobilitaet-in-deutschland.de/publikationen2023.html>. Exact requested/final URLs, retrieval times, sizes and SHA256 hashes are in `sources/download_manifest.json` and the workbook's **Provenance** sheet.

| Local original in `sources/` | Use in this task |
|---|---|
| `infas_Tabellen_MiD2023_7555_Bund.pdf` | September 2025 V2 national tables; 373 pages. Independent checks of sample sizes, rounded mode shares and purposes. Main numerical inputs instead use the more precise public MiT responses. |
| `infas_HandbuchZurDatennutzung_MiD2023_7555.pdf` | 40 pages. Population, dataset relationships, eligibility, recall periods, weights and missing-data conventions. |
| `infas_Methodenbericht_MiD2023_7555.pdf` | 72 pages. Survey design and weighting reference. Downloaded and read for methodology, not a source of aircraft cell estimates. |
| `infas_ErgänzendeStudienunterlagen_MiD2023_7555.pdf` | 238 pages. Exact questions and derived-variable rules. PDF pp21/23: outward and return modes combined; pp164/169: aircraft-first main-mode hierarchy; pp164/168: companion processing. |
| `MiD2023_Ergebnisbericht.pdf` | 240 pages. General interpretive reference retained in archive; not transcribed into the aircraft data table. |
| `MiD2023_StudySummary.pdf` | One-page English overview; survey period and national scope. |
| `MiD2023_Codeplaene_A_AbsolutAnonym.zip` | Despite its name, contains A, B1, B2 and B3 codebooks. All four extracted unchanged. **Only B1 was read for the study dictionary.** These workbooks are documentation, not respondent records. |
| `MiD2023_Datensatzpakete_Inhalte.zip` | Extracted `MiD2023_Datensatzpakete_Inhalte.xlsx`; checked package/table contents. |
| `publikationen2023.html` | Dated catalogue snapshot supporting discovery and source URLs. |

Extracted B1 codebook: `sources/extracted/MiD2023_Codeplaene_A_AbsolutAnonym/MiD2023_Codepläne_B1_Standard.xlsx`. The workbook's **B1 dictionary** contains 231 table-variable entries selected from this file: public-query variables, identifiers, weights, raw mode indicators, journey characteristics, stage fields and candidate persona attributes. Repeated variable names across different source tables are intentionally retained. Original sheet and row are recorded. Code labels are preserved; no code definitions were invented.

Additional originals:

- `mit_sources/`: public MiT application/catalogue snapshots, 62 successful table JSON responses, exact POST requests, provenance and `MiT_official_age_and_mode_tables.xlsx` (22 source tables). Public service: <https://mobilitaet-in-tabellen-2023.bast.de/>.
- `muc_sources/MUC_annual_traffic_report_2025.pdf`: complete 22-page Munich report. Seventeen percentage rows were verified against printed pp11–12. The Gen Z definition is on printed p10.
- `muc_sources/MUC_PIP_sources.html`: <https://pip.munich-airport.de/sources>. An inventory of persona input sources, not a respondent dataset or age/access cross-tab.

## 2. What was queried

MiT's publicly served application exposes dataset and variable catalogues and a table endpoint. Only catalogue-listed variables were used. No login, respondent identifiers or restricted microdata were requested.

The exact query lists are `queries_initial.json`, `queries_profiles.json` and `queries_daily_context.json` in `mit_sources/`. Each successful response has adjacent `.request.json` and `.provenance.json` files. `successful_queries.json` inventories the successful table queries.

- Overnight/day profiles: age, sex, employment/activity, education, household size/type, cars, income/economic status, mobility tools, licence, mobility restrictions, residence state/urbanity, purpose, destination, distance, overnight duration and household companions.
- Multiple-response journey modes by main mode, including nine age strata.
- Four general flying-frequency context queries: age, sex, income and urbanity.
- Four diary aircraft-mention context queries: age, sex, purpose and distance.
- Nine exploratory diary main-mode tables retained in the raw archive only: public main-mode groups cannot isolate aircraft.

Three attempted multi-response column queries returned HTTP400 because MiT supports those sets only as rows. Their requests and errors are retained. Four transient connection resets were retried successfully. No missing outputs were guessed. The public catalogue offers no stage dataset or individual raw aircraft flags for querying.

This is a targeted collection of relevant public evidence, not every possible MiT cross-tabulation. Unrelated small-area estimates, presentation decks and duplicate language summaries were excluded.

## 3. Operational aircraft cohorts

For overnight journeys, select the `Flugzeug` column in tables conditioned on `hvm_r` (aircraft code 6). For day journeys, select the corresponding `hvm_tr` column (code 6). The official derivation gives aircraft highest priority, so reported aircraft use determines the journey's primary-mode category. Independent public mode cross-tabs confirm aircraft mention at 100% in the aircraft column and 0% in every other column.

The future B1 record selection should directly check `R_VM_I == 1` and `TR_VM_I == 1`, validating consistency with derived modes. Diary aircraft use is `W_VM_T == 1`, with ordered stages available only for eligible diary trips. Do not join diary stages to recalled overnight/day journeys as if they described the same event.

Overnight and day journeys are separate observations and recall windows. Several journeys may belong to one person. General flying frequency is person-level context and does not establish an observed flight in a specific recall period.

## 4. Cleaning and consolidation

The raw inputs are preserved unchanged. `mit_sources/normalize_mit.py` writes separate normalised JSON; `scripts/prepare_workbook.py` prepares typed workbook inputs.

1. Select aircraft-conditioned cells for the two journey modules. Keep non-aircraft columns only in original source responses.
2. Make one output row per published cell. Create a deterministic ID from source filename, table index, row and column. It is never a passenger identifier.
3. Move the selected column's `Basis (gewichtet)` and `Basis (ungewichtet)` into explicit denominator fields. Never use the response's all-mode top-level base as an aircraft denominator.
4. Preserve the raw cell JSON, rounded weighted cell count and exact returned percentage. Convert the percentage from 0–100 to an Excel fraction by dividing by 100; display one decimal percent. Detailed returned decimals do not imply corresponding statistical precision.
5. Trim leading/trailing spaces in category and variable-label display text. Keep German source labels, response categories and missing/design categories returned by MiT. No imputation or rebasing was performed.
6. Preserve a real zero separately from missing values. A rounded weighted count of zero can coexist with a positive percentage; neither was overwritten.
7. Mark multiple-response tables. Their category percentages need not sum to 100%.
8. Flag subgroup bases below 30 as exploratory. This is a project presentation rule, not an official MiD suppression threshold. No category-level unweighted count or design-based interval was fabricated.
9. Keep 538 primary cells separate from 226 context cells. Diary context percentages mean aircraft mentions **among all diary trips in the conditioning group**, not the composition of aircraft passengers. Habitual-frequency context uses its own person-level denominators.
10. Add the verified Munich aggregates, B1 dictionary, study design, remaining data requests and provenance to one workbook.

The API applies variable-specific eligibility/valid-data bases. Retaining every returned category does not mean the API includes every original missing record. Always use the base on the same row.

**Companion example:** MiT overnight `anzbegl_gr` has N=8,897 and weighted base=8,512. The PDF's A R7 (PDF p358) additionally limits to multi-person households, with aircraft N=8,145 and weighted base=7,100. Thus its rounded 43% with no household companion is not directly comparable with the API's 58.856%. Source processing sets single-person households to zero and treats counts at least as large as household size as implausible. Zero never proves that a respondent travelled alone.

## 5. Weighting and interpretation

- `R_GEW`, `TR_GEW` and `P_GEW` are retained as returned by the relevant queries. Diary context retains its returned weight field.
- MiD weights are case-normalised. Rounded weighted bases 9,069 and 390 are not estimates of Germany's total air-passenger population.
- The headline unweighted bases are 9,475 overnight aircraft journeys and 454 aircraft day journeys. They are not unique-person counts and must not be pooled.
- Journey weights account for reported journey frequency; see handbook weighting section. Do not annualise up-to-three detailed records by multiplying them by four or thirteen.
- Ground-mode lists combine the outward and return journey. They establish co-use, not airport identity, direction, stage sequence or the precise access side.
- The public age band 18–29 is not Munich's Gen Z birth-year definition 1995–2010.

## 6. Munich comparison

The 17 included 2025 rows comprise six access modes, five age groups, two residence groups, two passenger types and two purposes. Each of the five distributions sums to 100%. Exact source pages and qualifications are attached to every row.

The source includes foreign-resident passengers and transfer passengers; MiD represents residents of Germany. Passenger-intercept samples also differ from population samples in their exposure to frequent travellers. No direct statistical MiD–Munich comparison or age/access cross-tab was inferred.

Request age/birth-year × access mode × residence × originating/transfer cross-tabs with weighted estimates, unweighted counts, survey year, question wording and eligibility. Prefer matching 2023/24 data, retaining 2025 for change analysis. The PIP source inventory can guide requests for underlying airport surveys and persona definitions.

2024 report downloads repeatedly returned HTTP500 and are excluded from numeric benchmarks. A 2025 duration chart carries 2019/2024 year labels and was excluded. The 2026 advertising brochure's inconsistent car figure was not mixed into the annual-report estimates.

## 7. Validation performed

- Download hashes verified; six MiD PDFs and the Munich PDF parsed successfully; ZIP members extracted safely.
- All 538 aircraft cells independently matched to their raw query cell, rounded count, percentage and two bases.
- All 41 single-response primary distributions sum to 100% within numerical tolerance. Multiple-response totals are deliberately not subjected to that rule.
- Aircraft-main-mode equivalence checked against both official derivation documentation and raw mode cross-tabs.
- Independent PDF spot checks: overnight car/local rail-bus/long-distance rail round to 38%/22%/12% (A R4, PDF p352); day car/long-distance rail to 34%/21% (A TR4, p368); business purpose to 26% overnight (A R1, p346) and 49% day journey (A TR1, p362).
- Overnight age 18–29 mode base is N=1,262, weighted 1,881. Several day-journey age bases are 4, 5, 9, 25 or 27; strong subgroup claims would be inappropriate.
- Workbook formula inspection, exported cell-value checks, table/filter checks and rendered views of all nine sheets are recorded in `intermediate/`. Validation uses the artifact-tool engine and a read-only XLSX parser; desktop Excel recalculation was not separately run.

## 8. Reproduce or extend

Keep this dated snapshot intact. For a future release, copy the scripts and query specifications into a new dated directory. Python needs `pdfplumber`, `pypdf` and `openpyxl` (read-only use). Workbook authoring uses Node.js and `@oai/artifact-tool`. This task used the Codex bundled runtime; the runtime itself is not included in the archive.

Run from the archive root with `python` and `node` pointing to suitable runtimes:

```text
python scripts/download_sources.py
python mit_sources/collect_mit.py
python mit_sources/collect_mit.py prepare
python mit_sources/collect_mit.py mit_sources/queries_initial.json
python mit_sources/collect_mit.py mit_sources/queries_profiles.json
python mit_sources/collect_mit.py mit_sources/queries_daily_context.json
python mit_sources/collect_mit.py export
python mit_sources/normalize_mit.py
python scripts/inspect_sources.py
python scripts/prepare_workbook.py
node scripts/build_workbook.mjs
python scripts/validate_workbook.py
```

The MiT collector caches successful files; use a new directory to request a fresh snapshot. MUC source acquisition/verification is separately documented by scripts and manifests in `muc_sources/`. The B1 variable dictionary is regenerated from the original official codebook, not manually transcribed. No statistical models or LLM experiments were trained in this task.
